clear all
close all
mu=2;
sigma=1;
x=-5:0.1:5;
evaluate_gaussian(x,mu,sigma);